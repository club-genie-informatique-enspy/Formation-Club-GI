/**
 * SOLUTION EXERCICE 2 - GALERIE PHOTOS
 * 
 * API : Lorem Picsum (https://picsum.photos/)
 * Cette API est gratuite, sans authentification, et supporte CORS
 */

// ==========================================
// SÉLECTION DES ÉLÉMENTS DU DOM
// ==========================================

const loadBtn = document.querySelector('#loadBtn');
const gallery = document.querySelector('#gallery');
const loadingSpinner = document.querySelector('#loadingSpinner');
const errorMessage = document.querySelector('#errorMessage');

// URL de l'API Lorem Picsum
const API_URL = 'https://picsum.photos/v2/list?page=1&limit=9';


// ==========================================
// FONCTION POUR AFFICHER/CACHER LE LOADING
// ==========================================

function toggleLoading(isLoading) {
    if (isLoading) {
        loadingSpinner.classList.remove('hidden');
        loadBtn.disabled = true;
        loadBtn.style.opacity = '0.5';
        loadBtn.style.cursor = 'not-allowed';
    } else {
        loadingSpinner.classList.add('hidden');
        loadBtn.disabled = false;
        loadBtn.style.opacity = '1';
        loadBtn.style.cursor = 'pointer';
    }
}


// ==========================================
// FONCTION POUR AFFICHER/CACHER L'ERREUR
// ==========================================

function toggleError(hasError) {
    if (hasError) {
        errorMessage.classList.remove('hidden');
    } else {
        errorMessage.classList.add('hidden');
    }
}


// ==========================================
// FONCTION POUR CRÉER UNE CARTE PHOTO
// ==========================================

function createPhotoCard(photo) {
    const card = document.createElement('div');
    card.classList.add('photo-card');
    
    // Lorem Picsum retourne : { id, author, width, height, url, download_url }
    // On construit l'URL avec une taille fixe : 400x300
    const imageUrl = `https://picsum.photos/id/${photo.id}/400/300`;
    
    card.innerHTML = `
        <img src="${imageUrl}" alt="Photo par ${photo.author}">
        <div class="photo-info">
            <div class="photo-title">Photo par ${photo.author}</div>
            <div class="photo-id">Photo #${photo.id}</div>
        </div>
    `;
    
    return card;
}


// ==========================================
// FONCTION PRINCIPALE - CHARGER LES PHOTOS
// ==========================================

async function loadPhotos() {
    // Vider la galerie
    gallery.innerHTML = '';
    
    // Cacher le message d'erreur
    toggleError(false);
    
    // Afficher le loading
    toggleLoading(true);
    
    try {
        // Faire la requête fetch
        const response = await fetch(API_URL);
        
        // Vérifier si la réponse est OK
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        
        // Convertir en JSON
        const photos = await response.json();
        
        // Vérifier qu'on a des photos
        if (!photos || photos.length === 0) {
            throw new Error('Aucune photo trouvée');
        }
        
        // Pour chaque photo, créer une carte et l'ajouter
        photos.forEach(photo => {
            const card = createPhotoCard(photo);
            gallery.appendChild(card);
        });
        
        console.log(`${photos.length} photos chargées avec succès !`);
        
    } catch (error) {
        console.error('Erreur lors du chargement des photos:', error);
        toggleError(true);
        
    } finally {
        toggleLoading(false);
    }
}


// ==========================================
// EVENT LISTENERS
// ==========================================

loadBtn.addEventListener('click', loadPhotos);


// ==========================================
// NOTES PÉDAGOGIQUES
// ==========================================

/**
 * POINTS CLÉS À EXPLIQUER PENDANT LA CORRECTION :
 * 
 * 1. LOREM PICSUM
 *    - API spécialisée pour images placeholder
 *    - Images haute qualité (Unsplash)
 *    - Pas de problèmes CORS
 *    - Structure : { id, author, width, height, url, download_url }
 * 
 * 2. CONSTRUCTION D'URL D'IMAGE
 *    - Format : https://picsum.photos/id/{ID}/{WIDTH}/{HEIGHT}
 *    - Exemple : https://picsum.photos/id/237/400/300
 * 
 * 3. async/await
 *    - async : déclare une fonction asynchrone
 *    - await : attend la résolution d'une Promise
 * 
 * 4. fetch()
 *    - Retourne une Promise
 *    - Par défaut, fait une requête GET
 * 
 * 5. try...catch...finally
 *    - try : code qui peut générer une erreur
 *    - catch : gestion de l'erreur
 *    - finally : s'exécute toujours
 */