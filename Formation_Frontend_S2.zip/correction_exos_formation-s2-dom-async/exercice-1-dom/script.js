/**
 * SOLUTION EXERCICE 1 - LISTE DE COURSES
 * 
 * Ce fichier contient la solution complète de l'exercice.
 * À utiliser uniquement pour la correction pendant la formation.
 */

// ==========================================
// SÉLECTION DES ÉLÉMENTS DU DOM
// ==========================================

const itemInput = document.querySelector('#itemInput');
const addBtn = document.querySelector('#addBtn');
const shoppingList = document.querySelector('#shoppingList');
const totalItems = document.querySelector('#totalItems');


// ==========================================
// FONCTION POUR AJOUTER UN ARTICLE
// ==========================================

function addItem() {
    // Récupérer la valeur de l'input et enlever les espaces
    const itemText = itemInput.value.trim();
    
    // Vérifier que l'input n'est pas vide
    if (itemText === '') {
        alert('Veuillez entrer un article');
        return;
    }
    
    // Créer un élément <li>
    const li = document.createElement('li');
    
    // Définir le contenu HTML du li
    li.innerHTML = `
        <span class="item-text">${itemText}</span>
        <button class="delete-btn">×</button>
    `;
    
    // Ajouter un event listener sur le li entier pour barrer/débarrer
    li.addEventListener('click', toggleCompleted);
    
    // Sélectionner le bouton supprimer et ajouter son event listener
    const deleteBtn = li.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', deleteItem);
    
    // Ajouter le li à la liste
    shoppingList.appendChild(li);
    
    // Vider l'input
    itemInput.value = '';
    
    // Remettre le focus sur l'input pour faciliter l'ajout d'autres articles
    itemInput.focus();
    
    // Mettre à jour le compteur
    updateCounter();
}


// ==========================================
// FONCTION POUR SUPPRIMER UN ARTICLE
// ==========================================

function deleteItem(event) {
    // Empêcher la propagation pour éviter que le clic déclenche aussi toggleCompleted
    event.stopPropagation();
    
    // Récupérer l'élément li parent du bouton cliqué
    const li = event.target.parentElement;
    
    // Supprimer le li du DOM
    li.remove();
    
    // Mettre à jour le compteur
    updateCounter();
}


// ==========================================
// FONCTION POUR BARRER/DÉBARRER UN ARTICLE
// ==========================================

function toggleCompleted(event) {
    // Récupérer l'élément li cliqué
    // Utiliser currentTarget pour avoir toujours le li, même si on clique sur le span
    const li = event.currentTarget;
    
    // Toggle la classe 'completed'
    li.classList.toggle('completed');
}


// ==========================================
// FONCTION POUR METTRE À JOUR LE COMPTEUR
// ==========================================

function updateCounter() {
    // Compter le nombre d'éléments li dans la liste
    const count = shoppingList.querySelectorAll('li').length;
    
    // Mettre à jour le textContent du compteur
    totalItems.textContent = count;
}


// ==========================================
// EVENT LISTENERS
// ==========================================

// Ajouter un article au clic du bouton
addBtn.addEventListener('click', addItem);

// Ajouter un article avec la touche Enter
itemInput.addEventListener('keypress', (event) => {
    if (event.key === 'Enter') {
        addItem();
    }
});


// ==========================================
// INITIALISATION
// ==========================================

// Mettre à jour le compteur au chargement (devrait afficher 0)
updateCounter();

// Mettre le focus sur l'input au chargement
itemInput.focus();


// ==========================================
// NOTES PÉDAGOGIQUES
// ==========================================

/**
 * POINTS CLÉS À EXPLIQUER PENDANT LA CORRECTION :
 * 
 * 1. querySelector vs querySelectorAll
 *    - querySelector retourne le premier élément
 *    - querySelectorAll retourne une NodeList (comme un tableau)
 * 
 * 2. trim()
 *    - Enlève les espaces au début et à la fin
 *    - Évite d'ajouter des articles vides
 * 
 * 3. event.stopPropagation()
 *    - Empêche la propagation de l'événement aux éléments parents
 *    - Nécessaire pour que le clic sur supprimer ne déclenche pas toggleCompleted
 * 
 * 4. event.target vs event.currentTarget
 *    - target : l'élément exact qui a été cliqué (peut être le span)
 *    - currentTarget : l'élément sur lequel l'event listener est attaché (toujours le li)
 * 
 * 5. classList.toggle()
 *    - Ajoute la classe si elle n'existe pas
 *    - Retire la classe si elle existe déjà
 * 
 * 6. Template literals (backticks)
 *    - Permettent d'insérer des variables dans les strings : ${variable}
 *    - Plus lisible que la concaténation avec +
 * 
 * AMÉLIORATIONS POSSIBLES À DISCUTER :
 * - Validation plus poussée (longueur min/max)
 * - Sauvegarde dans localStorage
 * - Animation lors de l'ajout/suppression
 * - Bouton "Tout supprimer"
 * - Édition des articles existants
 */