/**
 * SOLUTION MINI-PROJET - GESTIONNAIRE DE TÂCHES
 * 
 * API : DummyJSON (https://dummyjson.com/)
 * Cette API est gratuite, sans authentification, et supporte CORS
 */

// ==========================================
// SÉLECTION DES ÉLÉMENTS
// ==========================================

const taskInput = document.querySelector('#taskInput');
const addTaskBtn = document.querySelector('#addTaskBtn');
const tasksList = document.querySelector('#tasksList');
const loadingState = document.querySelector('#loadingState');
const errorState = document.querySelector('#errorState');
const retryBtn = document.querySelector('#retryBtn');

// Compteurs
const totalTasksEl = document.querySelector('#totalTasks');
const completedTasksEl = document.querySelector('#completedTasks');
const pendingTasksEl = document.querySelector('#pendingTasks');

// Configuration API
const API_URL = 'https://dummyjson.com/todos';
const LIMIT = 10; // Nombre de tâches à charger

// Tableau pour stocker les tâches localement
let tasks = [];


// ==========================================
// FONCTIONS UTILITAIRES
// ==========================================

function toggleLoading(show) {
    if (show) {
        loadingState.classList.remove('hidden');
        tasksList.innerHTML = '';
    } else {
        loadingState.classList.add('hidden');
    }
}

function toggleError(show) {
    if (show) {
        errorState.classList.remove('hidden');
        tasksList.innerHTML = '';
    } else {
        errorState.classList.add('hidden');
    }
}

function updateStats() {
    const total = tasks.length;
    const completed = tasks.filter(task => task.completed).length;
    const pending = total - completed;
    
    totalTasksEl.textContent = total;
    completedTasksEl.textContent = completed;
    pendingTasksEl.textContent = pending;
}

function createTaskElement(task) {
    const taskItem = document.createElement('div');
    taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
    taskItem.dataset.id = task.id;
    
    taskItem.innerHTML = `
        <input 
            type="checkbox" 
            class="task-checkbox" 
            ${task.completed ? 'checked' : ''}
        >
        <span class="task-text">${task.todo}</span>
        <span class="task-id">#${task.id}</span>
        <button class="btn-delete">🗑️ Supprimer</button>
    `;
    
    const checkbox = taskItem.querySelector('.task-checkbox');
    const deleteBtn = taskItem.querySelector('.btn-delete');
    
    checkbox.addEventListener('change', () => toggleTask(task.id));
    deleteBtn.addEventListener('click', () => deleteTask(task.id));
    
    return taskItem;
}

function renderTasks() {
    tasksList.innerHTML = '';
    
    tasks.forEach(task => {
        const taskElement = createTaskElement(task);
        tasksList.appendChild(taskElement);
    });
    
    updateStats();
}


// ==========================================
// FONCTION 1 : RÉCUPÉRER LES TÂCHES (GET)
// ==========================================

async function fetchTasks() {
    toggleLoading(true);
    toggleError(false);
    
    try {
        const response = await fetch(`${API_URL}?limit=${LIMIT}`);
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        
        const data = await response.json();
        
        // DummyJSON retourne { todos: [...], total, skip, limit }
        tasks = data.todos;
        renderTasks();
        
        console.log(`${tasks.length} tâches chargées avec succès`);
        
    } catch (error) {
        console.error('Erreur lors du chargement:', error);
        toggleError(true);
    } finally {
        toggleLoading(false);
    }
}


// ==========================================
// FONCTION 2 : AJOUTER UNE TÂCHE (POST)
// ==========================================

async function addTask() {
    const todoText = taskInput.value.trim();
    
    if (!todoText) {
        alert('Veuillez entrer une tâche');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/add`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                todo: todoText,
                completed: false,
                userId: 1
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        
        const newTask = await response.json();
        
        // Ajouter la nouvelle tâche au début du tableau
        tasks.unshift(newTask);
        renderTasks();
        
        // Vider l'input
        taskInput.value = '';
        taskInput.focus();
        
        console.log('Tâche ajoutée:', newTask);
        
    } catch (error) {
        console.error('Erreur lors de l\'ajout:', error);
        alert('Impossible d\'ajouter la tâche');
    }
}


// ==========================================
// FONCTION 3 : MARQUER COMME COMPLÉTÉE (PUT)
// ==========================================

async function toggleTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) {
        console.error('Tâche non trouvée');
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/${taskId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                completed: !task.completed
            })
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        
        // Mettre à jour l'état local
        task.completed = !task.completed;
        renderTasks();
        
        console.log('Tâche mise à jour:', task);
        
    } catch (error) {
        console.error('Erreur lors de la mise à jour:', error);
        // Annuler le changement en cas d'erreur
        task.completed = !task.completed;
    }
}


// ==========================================
// FONCTION 4 : SUPPRIMER UNE TÂCHE (DELETE)
// ==========================================

async function deleteTask(taskId) {
    if (!confirm('Voulez-vous vraiment supprimer cette tâche ?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/${taskId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error(`Erreur HTTP : ${response.status}`);
        }
        
        // Retirer la tâche du tableau
        tasks = tasks.filter(task => task.id !== taskId);
        renderTasks();
        
        console.log(`Tâche #${taskId} supprimée`);
        
    } catch (error) {
        console.error('Erreur lors de la suppression:', error);
        alert('Impossible de supprimer la tâche');
    }
}


// ==========================================
// EVENT LISTENERS
// ==========================================

addTaskBtn.addEventListener('click', addTask);

taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        addTask();
    }
});

retryBtn.addEventListener('click', fetchTasks);


// ==========================================
// INITIALISATION
// ==========================================

fetchTasks();


// ==========================================
// NOTES PÉDAGOGIQUES
// ==========================================

/**
 * POINTS CLÉS À EXPLIQUER PENDANT LA CORRECTION :
 * 
 * 1. DUMMYJSON vs JSONPLACEHOLDER
 *    - DummyJSON : API moderne avec CORS garanti
 *    - Structure différente : { todos: [...], total, skip, limit }
 *    - Utilise "todo" au lieu de "title"
 *    - Endpoint /add pour POST
 * 
 * 2. CRUD COMPLET
 *    - Create (POST) : /todos/add
 *    - Read (GET) : /todos?limit=10
 *    - Update (PUT) : /todos/{id}
 *    - Delete (DELETE) : /todos/{id}
 * 
 * 3. MÉTHODES HTTP
 *    - GET : récupérer des données
 *    - POST : créer une ressource
 *    - PUT : modifier une ressource
 *    - DELETE : supprimer une ressource
 * 
 * 4. HEADERS
 *    - Content-Type: application/json
 *    - Nécessaire pour POST et PUT
 * 
 * 5. GESTION D'ÉTAT
 *    - Le tableau tasks est notre "source de vérité"
 *    - Toujours mettre à jour tasks avant renderTasks()
 */