# 📚 Cours Complet : Asynchrone et DOM
**Formation S2 - Club Génie Informatique ENSPY**
# Formateur: NKAMLA CHEDJOU JOHAN
# Assistants: NATHANAEL ZUCHUON & WOKMENI RAÏSSAWY
---

## 📋 Table des Matières

1. [Introduction](#introduction)
2. [Partie 1 : Manipulation du DOM](#partie-1--manipulation-du-dom)
   - [Qu'est-ce que le DOM ?](#quest-ce-que-le-dom-)
   - [Sélectionner des éléments](#sélectionner-des-éléments)
   - [Modifier le contenu](#modifier-le-contenu)
   - [Modifier le style](#modifier-le-style)
   - [Créer et supprimer des éléments](#créer-et-supprimer-des-éléments)
   - [Gérer les événements](#gérer-les-événements)
3. [Partie 2 : Programmation Asynchrone](#partie-2--programmation-asynchrone)
   - [Le problème du code synchrone](#le-problème-du-code-synchrone)
   - [Les Promises](#les-promises)
   - [Async/Await](#asyncawait)
   - [Fetch API](#fetch-api)
   - [CRUD avec Fetch](#crud-avec-fetch)
4. [Exercices Pratiques](#exercices-pratiques)
5. [Ressources Supplémentaires](#ressources-supplémentaires)

---

## Introduction

Bienvenue dans ce cours complet sur la **manipulation du DOM** et la **programmation asynchrone** en JavaScript. Ces deux concepts sont fondamentaux pour créer des applications web modernes et interactives.

### 🎯 Objectifs d'apprentissage

À la fin de ce cours, vous serez capable de :
- ✅ Manipuler le DOM pour créer des interfaces dynamiques
- ✅ Comprendre et utiliser la programmation asynchrone
- ✅ Effectuer des requêtes HTTP avec Fetch API
- ✅ Créer une application CRUD complète

### ⏱️ Durée estimée
Environ 3-4 heures de lecture et pratique

---

## Partie 1 : Manipulation du DOM

### Qu'est-ce que le DOM ?

Le **DOM (Document Object Model)** est une représentation en arborescence de votre page HTML que JavaScript peut manipuler.

#### Structure du DOM

Imaginez votre HTML comme un arbre :

```
document
  └── html
      ├── head
      │   └── title
      └── body
          ├── header
          │   └── h1
          ├── main
          │   ├── section
          │   └── article
          └── footer
```

Chaque élément HTML devient un **objet** que JavaScript peut :
- Lire
- Modifier
- Créer
- Supprimer

#### Exemple concret

**HTML :**
```html
<!DOCTYPE html>
<html>
<head>
    <title>Ma Page</title>
</head>
<body>
    <h1 id="titre">Bonjour le monde</h1>
    <p class="description">Ceci est un paragraphe</p>
</body>
</html>
```

**Représentation DOM :**
- `document` est la racine
- `document.body` contient tout le contenu visible
- `document.getElementById('titre')` permet d'accéder au `<h1>`

---

### Sélectionner des éléments

Pour manipuler un élément, il faut d'abord le **sélectionner**.

#### Méthode moderne : `querySelector`

La méthode recommandée utilise la même syntaxe que les **sélecteurs CSS**.

```javascript
// Sélectionner le premier élément qui correspond
const titre = document.querySelector('h1');
const menu = document.querySelector('#menu');  // Par ID
const bouton = document.querySelector('.btn-primary');  // Par classe

// Sélectionner TOUS les éléments qui correspondent
const paragraphes = document.querySelectorAll('p');
const items = document.querySelectorAll('.item');
```

#### Exemples de sélecteurs

```javascript
// Par balise
document.querySelector('h1');

// Par ID (précédé de #)
document.querySelector('#menu');

// Par classe (précédée de .)
document.querySelector('.btn-primary');

// Par attribut
document.querySelector('[data-id="5"]');
document.querySelector('[type="email"]');

// Combinaisons (comme en CSS)
document.querySelector('div.container > p');
document.querySelector('nav ul li:first-child');
document.querySelector('.card .title');
```

#### Différence entre querySelector et querySelectorAll

```javascript
// querySelector → retourne LE PREMIER élément
const premierParagraphe = document.querySelector('p');
console.log(premierParagraphe); // Un seul élément

// querySelectorAll → retourne TOUS les éléments (NodeList)
const tousParagraphes = document.querySelectorAll('p');
console.log(tousParagraphes); // [p, p, p, p]

// Pour parcourir tous les éléments
tousParagraphes.forEach(paragraphe => {
    console.log(paragraphe.textContent);
});
```

#### ⚠️ Méthodes anciennes (à éviter)

Ces méthodes existent toujours mais sont moins flexibles :

```javascript
// À éviter (anciennes méthodes)
document.getElementById('menu');  // Seulement par ID
document.getElementsByClassName('btn');  // Retourne HTMLCollection
document.getElementsByTagName('p');  // Retourne HTMLCollection

// Préférez toujours querySelector/querySelectorAll
```

---

### Modifier le contenu

Une fois un élément sélectionné, vous pouvez modifier son contenu.

#### textContent vs innerHTML

```javascript
const titre = document.querySelector('h1');

// textContent → Modifier uniquement le TEXTE
titre.textContent = "Nouveau titre";
// Résultat : <h1>Nouveau titre</h1>

// innerHTML → Modifier le CONTENU HTML
titre.innerHTML = "<strong>Titre</strong> important";
// Résultat : <h1><strong>Titre</strong> important</h1>
```

#### ⚠️ Sécurité : textContent vs innerHTML

```javascript
const userInput = "<script>alert('Hack!')</script>";

// ✅ SÉCURISÉ - Le script ne s'exécute pas
element.textContent = userInput;
// Affiche littéralement : <script>alert('Hack!')</script>

// ❌ DANGEREUX - Le script pourrait s'exécuter
element.innerHTML = userInput;
// Pourrait exécuter du code malveillant
```

**Règle d'or :** Utilisez `textContent` sauf si vous avez vraiment besoin d'insérer du HTML.

#### Modifier les valeurs des inputs

```javascript
const inputNom = document.querySelector('#nom');
const inputEmail = document.querySelector('#email');

// Lire la valeur
console.log(inputNom.value);

// Modifier la valeur
inputNom.value = "Jean Dupont";
inputEmail.value = "jean@example.com";

// Vider un input
inputNom.value = "";
```

#### Exemples pratiques

```javascript
// Exemple 1 : Afficher un message de bienvenue
const username = "Marie";
const messageElement = document.querySelector('#message');
messageElement.textContent = `Bienvenue ${username} !`;

// Exemple 2 : Récupérer et afficher une saisie utilisateur
const input = document.querySelector('#search');
const resultat = document.querySelector('#resultat');

const recherche = input.value;
resultat.textContent = `Vous avez recherché : ${recherche}`;

// Exemple 3 : Mettre à jour un compteur
const compteur = document.querySelector('#compteur');
let valeur = parseInt(compteur.textContent);
valeur++;
compteur.textContent = valeur;
```

---

### Modifier le style

Il existe deux façons principales de modifier l'apparence d'un élément.

#### Méthode 1 : classList (recommandée)

La meilleure approche consiste à utiliser des **classes CSS** et à les ajouter/retirer avec JavaScript.

```javascript
const bouton = document.querySelector('#monBouton');

// Ajouter une classe
bouton.classList.add('actif');
// <button class="actif">Cliquez</button>

// Retirer une classe
bouton.classList.remove('actif');
// <button class="">Cliquez</button>

// Basculer une classe (toggle)
bouton.classList.toggle('actif');
// Si la classe existe, elle est retirée
// Si elle n'existe pas, elle est ajoutée

// Vérifier si une classe existe
if (bouton.classList.contains('actif')) {
    console.log('Le bouton est actif');
}
```

**CSS :**
```css
.actif {
    background-color: green;
    color: white;
}

.cache {
    display: none;
}

.highlight {
    border: 2px solid yellow;
    background-color: lightyellow;
}
```

**JavaScript :**
```javascript
// Activer un bouton
bouton.classList.add('actif');

// Cacher un élément
element.classList.add('cache');

// Mettre en surbrillance
element.classList.add('highlight');
```

#### Méthode 2 : style (pour modifications ponctuelles)

```javascript
const element = document.querySelector('#monElement');

// Modifier des propriétés CSS directement
element.style.backgroundColor = 'blue';
element.style.color = 'white';
element.style.fontSize = '20px';
element.style.display = 'none';

// ⚠️ Note : Les propriétés CSS avec tirets deviennent camelCase
// CSS: background-color → JavaScript: backgroundColor
// CSS: font-size → JavaScript: fontSize
```

#### Quelle méthode choisir ?

```javascript
// ✅ BON : Utiliser classList pour des styles réutilisables
element.classList.add('error');  // Défini dans le CSS

// ❌ MOINS BON : Modifier style directement
element.style.color = 'red';
element.style.border = '1px solid red';
```

**Pourquoi classList est mieux ?**
- ✅ Sépare le style (CSS) de la logique (JavaScript)
- ✅ Réutilisable et maintenable
- ✅ Permet de grouper plusieurs styles ensemble
- ✅ Plus facile à lire

#### Exemple complet : Système d'onglets

**HTML :**
```html
<div class="tabs">
    <button class="tab active" data-tab="1">Onglet 1</button>
    <button class="tab" data-tab="2">Onglet 2</button>
    <button class="tab" data-tab="3">Onglet 3</button>
</div>

<div class="content active" id="content-1">Contenu 1</div>
<div class="content" id="content-2">Contenu 2</div>
<div class="content" id="content-3">Contenu 3</div>
```

**CSS :**
```css
.tab.active {
    background-color: blue;
    color: white;
}

.content {
    display: none;
}

.content.active {
    display: block;
}
```

**JavaScript :**
```javascript
const tabs = document.querySelectorAll('.tab');

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        // Retirer 'active' de tous les onglets
        tabs.forEach(t => t.classList.remove('active'));
        
        // Ajouter 'active' à l'onglet cliqué
        tab.classList.add('active');
        
        // Gérer l'affichage du contenu
        const tabId = tab.dataset.tab;
        document.querySelectorAll('.content').forEach(c => {
            c.classList.remove('active');
        });
        document.querySelector(`#content-${tabId}`).classList.add('active');
    });
});
```

---

### Créer et supprimer des éléments

#### Créer des éléments

Pour ajouter dynamiquement du contenu à votre page :

```javascript
// 1. Créer l'élément
const nouveauParagraphe = document.createElement('p');

// 2. Définir son contenu
nouveauParagraphe.textContent = "Ceci est un nouveau paragraphe";

// 3. Optionnel : Ajouter des classes ou attributs
nouveauParagraphe.classList.add('nouveau');
nouveauParagraphe.id = 'para-1';

// 4. L'ajouter au DOM
const container = document.querySelector('#container');
container.appendChild(nouveauParagraphe);
```

#### Différentes méthodes d'ajout

```javascript
const parent = document.querySelector('#liste');
const nouvelElement = document.createElement('li');
nouvelElement.textContent = "Nouvel item";

// appendChild → Ajouter à la fin
parent.appendChild(nouvelElement);

// prepend → Ajouter au début
parent.prepend(nouvelElement);

// before → Ajouter avant l'élément
parent.before(nouvelElement);

// after → Ajouter après l'élément
parent.after(nouvelElement);

// insertBefore → Insérer avant un élément spécifique
const premierItem = parent.querySelector('li:first-child');
parent.insertBefore(nouvelElement, premierItem);
```

#### Exemple : Ajouter des items à une liste

```javascript
const liste = document.querySelector('#maListe');
const input = document.querySelector('#nouveauItem');
const bouton = document.querySelector('#ajouter');

bouton.addEventListener('click', () => {
    // Récupérer la valeur de l'input
    const texte = input.value;
    
    // Vérifier que l'input n'est pas vide
    if (texte.trim() === '') {
        alert('Veuillez entrer un texte');
        return;
    }
    
    // Créer un nouvel élément <li>
    const nouvelItem = document.createElement('li');
    nouvelItem.textContent = texte;
    
    // L'ajouter à la liste
    liste.appendChild(nouvelItem);
    
    // Vider l'input
    input.value = '';
});
```

#### Supprimer des éléments

```javascript
const element = document.querySelector('#aSupprimer');

// Méthode 1 : remove() (moderne et simple)
element.remove();

// Méthode 2 : removeChild() (ancienne méthode)
const parent = element.parentNode;
parent.removeChild(element);
```

#### Exemple : Liste avec boutons de suppression

```javascript
function ajouterItem(texte) {
    const liste = document.querySelector('#liste');
    
    // Créer le <li>
    const item = document.createElement('li');
    item.textContent = texte;
    
    // Créer le bouton de suppression
    const boutonSupprimer = document.createElement('button');
    boutonSupprimer.textContent = 'Supprimer';
    boutonSupprimer.classList.add('btn-supprimer');
    
    // Gérer le clic sur le bouton
    boutonSupprimer.addEventListener('click', () => {
        item.remove();  // Supprimer tout le <li>
    });
    
    // Ajouter le bouton au <li>
    item.appendChild(boutonSupprimer);
    
    // Ajouter le <li> à la liste
    liste.appendChild(item);
}

// Utilisation
ajouterItem('Acheter du pain');
ajouterItem('Faire du sport');
```

#### Vider complètement un élément

```javascript
const container = document.querySelector('#container');

// Méthode 1 : innerHTML (rapide mais brutal)
container.innerHTML = '';

// Méthode 2 : Supprimer chaque enfant (plus propre)
while (container.firstChild) {
    container.removeChild(container.firstChild);
}

// Méthode 3 : replaceChildren (moderne)
container.replaceChildren();
```

---

### Gérer les événements

Les événements permettent de réagir aux actions de l'utilisateur.

#### addEventListener : La base

```javascript
const bouton = document.querySelector('#monBouton');

// Syntaxe de base
element.addEventListener('typeEvenement', fonction);

// Exemple avec fonction anonyme
bouton.addEventListener('click', function() {
    console.log('Bouton cliqué !');
});

// Exemple avec arrow function (plus moderne)
bouton.addEventListener('click', () => {
    console.log('Bouton cliqué !');
});

// Exemple avec fonction nommée
function gererClic() {
    console.log('Bouton cliqué !');
}
bouton.addEventListener('click', gererClic);
```

#### Types d'événements courants

```javascript
const element = document.querySelector('#element');

// 🖱️ Événements de souris
element.addEventListener('click', () => {});        // Clic
element.addEventListener('dblclick', () => {});     // Double-clic
element.addEventListener('mouseenter', () => {});   // Souris entre
element.addEventListener('mouseleave', () => {});   // Souris sort
element.addEventListener('mouseover', () => {});    // Survol
element.addEventListener('mousedown', () => {});    // Bouton pressé
element.addEventListener('mouseup', () => {});      // Bouton relâché

// ⌨️ Événements de clavier
element.addEventListener('keydown', () => {});      // Touche pressée
element.addEventListener('keyup', () => {});        // Touche relâchée
element.addEventListener('keypress', () => {});     // Touche appuyée

// 📝 Événements de formulaire
input.addEventListener('input', () => {});          // Saisie en cours
input.addEventListener('change', () => {});         // Valeur changée
form.addEventListener('submit', () => {});          // Soumission

// 🔄 Événements de page
window.addEventListener('load', () => {});          // Page chargée
window.addEventListener('resize', () => {});        // Fenêtre redimensionnée
window.addEventListener('scroll', () => {});        // Défilement
```

#### L'objet Event

Chaque événement passe automatiquement un objet `event` à la fonction :

```javascript
bouton.addEventListener('click', (event) => {
    console.log(event);  // Objet contenant toutes les infos
    
    // Propriétés utiles
    console.log(event.target);      // L'élément qui a déclenché l'événement
    console.log(event.type);        // Type d'événement ('click', 'keydown', etc.)
    console.log(event.currentTarget); // L'élément sur lequel l'écouteur est attaché
    
    // Méthodes utiles
    event.preventDefault();   // Empêcher le comportement par défaut
    event.stopPropagation();  // Arrêter la propagation de l'événement
});
```

#### Exemple 1 : Compteur de clics

```javascript
const bouton = document.querySelector('#compteur');
let compteur = 0;

bouton.addEventListener('click', () => {
    compteur++;
    bouton.textContent = `Cliqué ${compteur} fois`;
});
```

#### Exemple 2 : Validation de formulaire

```javascript
const form = document.querySelector('#monFormulaire');
const email = document.querySelector('#email');
const erreur = document.querySelector('#erreur');

form.addEventListener('submit', (event) => {
    // Empêcher l'envoi du formulaire
    event.preventDefault();
    
    // Valider l'email
    if (!email.value.includes('@')) {
        erreur.textContent = 'Email invalide';
        erreur.style.display = 'block';
        return;
    }
    
    // Si valide, on peut soumettre
    console.log('Formulaire valide !');
    form.submit();
});
```

#### Exemple 3 : Recherche en temps réel

```javascript
const searchInput = document.querySelector('#search');
const resultats = document.querySelector('#resultats');

searchInput.addEventListener('input', (event) => {
    const recherche = event.target.value.toLowerCase();
    
    // Filtrer les résultats
    const items = document.querySelectorAll('.item');
    items.forEach(item => {
        const texte = item.textContent.toLowerCase();
        
        if (texte.includes(recherche)) {
            item.style.display = 'block';  // Afficher
        } else {
            item.style.display = 'none';   // Cacher
        }
    });
});
```

#### Exemple 4 : Détecter les touches du clavier

```javascript
const input = document.querySelector('#monInput');

input.addEventListener('keydown', (event) => {
    console.log('Touche pressée:', event.key);
    
    // Détecter des touches spécifiques
    if (event.key === 'Enter') {
        console.log('Entrée pressée !');
    }
    
    if (event.key === 'Escape') {
        input.value = '';  // Vider l'input sur Echap
    }
    
    // Détecter les combinaisons
    if (event.ctrlKey && event.key === 's') {
        event.preventDefault();  // Empêcher Ctrl+S
        console.log('Sauvegarde !');
    }
});
```

#### preventDefault() : Cas d'usage

```javascript
// Empêcher la soumission d'un formulaire
form.addEventListener('submit', (event) => {
    event.preventDefault();
    // Traiter les données sans recharger la page
});

// Empêcher le clic droit
document.addEventListener('contextmenu', (event) => {
    event.preventDefault();
});

// Empêcher le comportement par défaut d'un lien
lien.addEventListener('click', (event) => {
    event.preventDefault();
    // Gérer la navigation en JavaScript
});
```

---

## Partie 2 : Programmation Asynchrone

### Le problème du code synchrone

JavaScript est **mono-thread** : il ne peut exécuter qu'une seule tâche à la fois.

#### Code bloquant (problématique)

```javascript
console.log('Début');

// Imagine une fonction qui prend 5 secondes
attendreCinqSecondes();  

console.log('Fin');  // Ceci n'apparaît qu'après 5 secondes !
```

**Problème :** Pendant les 5 secondes, RIEN d'autre ne peut se passer. La page est gelée, l'utilisateur ne peut pas interagir.

#### Métaphore du restaurant

**Mode synchrone (bloquant) :**
- Un serveur prend la commande du client 1
- Il va en cuisine et attend que le plat soit prêt (5 minutes)
- Il sert le client 1
- SEULEMENT APRÈS, il peut prendre la commande du client 2
- Résultat : Tout le restaurant attend !

**Mode asynchrone (non-bloquant) :**
- Le serveur prend la commande du client 1
- Il transmet la commande en cuisine
- PENDANT que la cuisine prépare, il prend les commandes des clients 2, 3, 4
- Quand un plat est prêt, il le sert
- Résultat : Service efficace !

En JavaScript :
- **Serveur** = JavaScript (mono-thread)
- **Cuisine** = Opérations longues (réseau, bases de données, fichiers)
- **Asynchrone** = JavaScript continue à travailler pendant que les opérations longues se font en arrière-plan

#### Opérations asynchrones typiques

- 🌐 Requêtes réseau (fetch, API)
- 💾 Lecture/écriture de fichiers
- ⏱️ Timers (setTimeout, setInterval)
- 🗄️ Accès à une base de données
- 🎥 Chargement d'images/vidéos

---

### Les Promises

Une **Promise** (promesse) est un objet représentant une valeur qui sera disponible maintenant, plus tard, ou jamais.

#### Les 3 états d'une Promise

```javascript
// 1. Pending (en attente) - État initial
// 2. Fulfilled (résolue) - Opération réussie
// 3. Rejected (rejetée) - Opération échouée
```

#### Syntaxe de base

```javascript
// Créer une Promise
const maPromesse = new Promise((resolve, reject) => {
    // Code asynchrone ici
    
    if (/* succès */) {
        resolve(resultat);  // Promise résolue
    } else {
        reject(erreur);     // Promise rejetée
    }
});

// Utiliser une Promise
maPromesse
    .then(resultat => {
        console.log('Succès:', resultat);
    })
    .catch(erreur => {
        console.log('Erreur:', erreur);
    });
```

#### Exemple simple : Simuler un chargement

```javascript
function chargerDonnees() {
    return new Promise((resolve, reject) => {
        console.log('Chargement en cours...');
        
        // Simuler un délai de 2 secondes
        setTimeout(() => {
            const donnees = { nom: 'Jean', age: 25 };
            resolve(donnees);  // Succès après 2 secondes
        }, 2000);
    });
}

// Utilisation
chargerDonnees()
    .then(donnees => {
        console.log('Données reçues:', donnees);
    })
    .catch(erreur => {
        console.log('Erreur:', erreur);
    });

console.log('Ceci apparaît immédiatement !');
```

**Ordre d'exécution :**
```
1. "Chargement en cours..."
2. "Ceci apparaît immédiatement !"
3. ... 2 secondes d'attente ...
4. "Données reçues: {nom: 'Jean', age: 25}"
```

#### Chaîner plusieurs Promises

```javascript
chargerUtilisateur()
    .then(utilisateur => {
        console.log('Utilisateur:', utilisateur);
        return chargerCommandes(utilisateur.id);
    })
    .then(commandes => {
        console.log('Commandes:', commandes);
        return chargerDetails(commandes[0].id);
    })
    .then(details => {
        console.log('Détails:', details);
    })
    .catch(erreur => {
        console.log('Erreur à n\'importe quelle étape:', erreur);
    });
```

---

### Async/Await

**Async/Await** est une syntaxe moderne qui rend le code asynchrone plus lisible, comme s'il était synchrone.

#### Syntaxe de base

```javascript
// Déclarer une fonction asynchrone avec 'async'
async function maFonction() {
    // Attendre une Promise avec 'await'
    const resultat = await unePromise();
    console.log(resultat);
}
```

#### Comparaison : Promises vs Async/Await

**Avec .then() (ancien style) :**
```javascript
function afficherUtilisateur() {
    fetch('https://api.example.com/user/1')
        .then(response => response.json())
        .then(data => {
            console.log(data);
        })
        .catch(error => {
            console.error(error);
        });
}
```

**Avec async/await (moderne) :**
```javascript
async function afficherUtilisateur() {
    try {
        const response = await fetch('https://api.example.com/user/1');
        const data = await response.json();
        console.log(data);
    } catch (error) {
        console.error(error);
    }
}
```

C'est plus clair et plus facile à lire !

#### Règles importantes

**Règle 1 : `await` uniquement dans fonction `async`**

```javascript
// ✅ CORRECT
async function maFonction() {
    const data = await fetch(url);
}

// ❌ ERREUR - await sans async
function maFonction() {
    const data = await fetch(url);  // ❌ Erreur de syntaxe
}
```

**Règle 2 : Toujours gérer les erreurs avec try/catch**

```javascript
async function chargerDonnees() {
    try {
        const response = await fetch(url);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Erreur lors du chargement:', error);
        // Gérer l'erreur de manière appropriée
    }
}
```

#### Exemple complet : Chargement de données

```javascript
async function afficherUtilisateurs() {
    try {
        // 1. Afficher un message de chargement
        console.log('Chargement des utilisateurs...');
        
        // 2. Récupérer les données
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        
        // 3. Vérifier que la requête a réussi
        if (!response.ok) {
            throw new Error('Erreur réseau');
        }
        
        // 4. Convertir en JSON
        const utilisateurs = await response.json();
        
        // 5. Afficher les résultats
        console.log('Utilisateurs:', utilisateurs);
        
        // 6. Faire quelque chose avec les données
        afficherDansLeDOM(utilisateurs);
        
    } catch (error) {
        console.error('Une erreur est survenue:', error);
        afficherMessageErreur('Impossible de charger les utilisateurs');
    }
}

// Appeler la fonction
afficherUtilisateurs();
```

#### Attendre plusieurs Promises en parallèle

```javascript
// ❌ Lent : Attend chaque requête l'une après l'autre (séquentiel)
async function chargerTout() {
    const users = await fetch('/api/users');      // Attend 2s
    const posts = await fetch('/api/posts');      // Attend 2s
    const comments = await fetch('/api/comments'); // Attend 2s
    // Total: 6 secondes
}

// ✅ Rapide : Lance toutes les requêtes en même temps (parallèle)
async function chargerTout() {
    const [users, posts, comments] = await Promise.all([
        fetch('/api/users'),
        fetch('/api/posts'),
        fetch('/api/comments')
    ]);
    // Total: 2 secondes (le temps de la plus longue requête)
}
```

---

### Fetch API

**Fetch** est l'API moderne pour effectuer des requêtes HTTP en JavaScript.

#### Syntaxe de base

```javascript
fetch(url)
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error(error));
```

#### Avec async/await (recommandé)

```javascript
async function recupererDonnees() {
    try {
        const response = await fetch('https://api.example.com/data');
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Erreur:', error);
    }
}
```

#### Structure d'une réponse Fetch

```javascript
const response = await fetch(url);

// Propriétés importantes
console.log(response.ok);          // true si status 200-299
console.log(response.status);      // Code HTTP (200, 404, 500, etc.)
console.log(response.statusText);  // "OK", "Not Found", etc.
console.log(response.headers);     // En-têtes de la réponse

// Méthodes pour lire le contenu
const data = await response.json();      // Convertir en JSON
const text = await response.text();      // Lire comme texte
const blob = await response.blob();      // Lire comme fichier binaire
```

#### Vérifier le succès de la requête

```javascript
async function chargerDonnees(url) {
    const response = await fetch(url);
    
    // Vérifier le statut HTTP
    if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
    }
    
    const data = await response.json();
    return data;
}
```

#### Exemple complet avec gestion d'erreurs

```javascript
async function afficherUtilisateur(id) {
    try {
        // 1. Faire la requête
        const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`);
        
        // 2. Vérifier le statut
        if (!response.ok) {
            throw new Error(`Utilisateur ${id} non trouvé`);
        }
        
        // 3. Extraire les données
        const utilisateur = await response.json();
        
        // 4. Afficher dans le DOM
        const container = document.querySelector('#utilisateur');
        container.innerHTML = `
            <h2>${utilisateur.name}</h2>
            <p>Email: ${utilisateur.email}</p>
            <p>Ville: ${utilisateur.address.city}</p>
        `;
        
    } catch (error) {
        console.error('Erreur:', error);
        
        // Afficher un message d'erreur à l'utilisateur
        const container = document.querySelector('#utilisateur');
        container.innerHTML = `
            <div class="error">
                Impossible de charger l'utilisateur.
            </div>
        `;
    }
}

// Utilisation
afficherUtilisateur(1);
```

---

### CRUD avec Fetch

**CRUD** signifie : Create (POST), Read (GET), Update (PUT), Delete (DELETE).

#### GET : Lire des données

```javascript
// Récupérer tous les utilisateurs
async function getUtilisateurs() {
    try {
        const response = await fetch('https://api.example.com/users');
        
        if (!response.ok) {
            throw new Error('Erreur de chargement');
        }
        
        const users = await response.json();
        return users;
    } catch (error) {
        console.error('Erreur GET:', error);
    }
}

// Récupérer un utilisateur spécifique
async function getUtilisateur(id) {
    const response = await fetch(`https://api.example.com/users/${id}`);
    const user = await response.json();
    return user;
}
```

#### POST : Créer des données

```javascript
async function creerUtilisateur(nouvelUtilisateur) {
    try {
        const response = await fetch('https://api.example.com/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(nouvelUtilisateur)
        });
        
        if (!response.ok) {
            throw new Error('Erreur lors de la création');
        }
        
        const utilisateurCree = await response.json();
        console.log('Utilisateur créé:', utilisateurCree);
        return utilisateurCree;
        
    } catch (error) {
        console.error('Erreur POST:', error);
    }
}

// Utilisation
const nouvelUtilisateur = {
    name: 'Jean Dupont',
    email: 'jean@example.com',
    age: 25
};

creerUtilisateur(nouvelUtilisateur);
```

#### PUT : Mettre à jour des données

```javascript
async function modifierUtilisateur(id, modifications) {
    try {
        const response = await fetch(`https://api.example.com/users/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(modifications)
        });
        
        if (!response.ok) {
            throw new Error('Erreur lors de la modification');
        }
        
        const utilisateurModifie = await response.json();
        console.log('Utilisateur modifié:', utilisateurModifie);
        return utilisateurModifie;
        
    } catch (error) {
        console.error('Erreur PUT:', error);
    }
}

// Utilisation
modifierUtilisateur(1, {
    name: 'Jean Martin',
    email: 'jean.martin@example.com'
});
```

#### PATCH : Modification partielle

```javascript
// PATCH = modifier seulement certains champs
async function modifierEmail(id, nouvelEmail) {
    const response = await fetch(`https://api.example.com/users/${id}`, {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email: nouvelEmail })
    });
    
    return await response.json();
}
```

#### DELETE : Supprimer des données

```javascript
async function supprimerUtilisateur(id) {
    try {
        const response = await fetch(`https://api.example.com/users/${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error('Erreur lors de la suppression');
        }
        
        console.log(`Utilisateur ${id} supprimé`);
        return true;
        
    } catch (error) {
        console.error('Erreur DELETE:', error);
        return false;
    }
}

// Utilisation
supprimerUtilisateur(5);
```

#### Tableau récapitulatif CRUD

| Méthode HTTP | Action | Utilisation | Corps (body) |
|--------------|--------|-------------|--------------|
| **GET** | Lire | Récupérer des données | Non |
| **POST** | Créer | Ajouter nouvelles données | Oui |
| **PUT** | Modifier | Remplacer complètement | Oui |
| **PATCH** | Modifier | Modifier partiellement | Oui |
| **DELETE** | Supprimer | Effacer des données | Non |

#### Exemple complet : Gestionnaire de tâches

```javascript
// API de base pour les tâches
const API_URL = 'https://jsonplaceholder.typicode.com/todos';

// GET - Récupérer toutes les tâches
async function getTaches() {
    try {
        const response = await fetch(API_URL);
        const taches = await response.json();
        return taches.slice(0, 5); // Limiter à 5 tâches
    } catch (error) {
        console.error('Erreur GET:', error);
    }
}

// POST - Créer une nouvelle tâche
async function creerTache(titre) {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                title: titre,
                completed: false,
                userId: 1
            })
        });
        
        const nouvelleTache = await response.json();
        console.log('Tâche créée:', nouvelleTache);
        return nouvelleTache;
    } catch (error) {
        console.error('Erreur POST:', error);
    }
}

// PUT - Marquer une tâche comme complétée
async function completerTache(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                completed: true
            })
        });
        
        const tacheModifiee = await response.json();
        console.log('Tâche complétée:', tacheModifiee);
        return tacheModifiee;
    } catch (error) {
        console.error('Erreur PUT:', error);
    }
}

// DELETE - Supprimer une tâche
async function supprimerTache(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            console.log(`Tâche ${id} supprimée`);
            return true;
        }
    } catch (error) {
        console.error('Erreur DELETE:', error);
        return false;
    }
}

// Afficher les tâches dans le DOM
async function afficherTaches() {
    const taches = await getTaches();
    const liste = document.querySelector('#listeTaches');
    
    liste.innerHTML = ''; // Vider la liste
    
    taches.forEach(tache => {
        const item = document.createElement('li');
        item.innerHTML = `
            <span class="${tache.completed ? 'complete' : ''}">
                ${tache.title}
            </span>
            <button onclick="completerTache(${tache.id})">✓</button>
            <button onclick="supprimerTache(${tache.id})">✗</button>
        `;
        liste.appendChild(item);
    });
}

// Initialiser au chargement de la page
afficherTaches();
```

---

## Exercices Pratiques

### 📦 Accéder aux exercices

Tous les exercices sont disponibles sur le **dépôt GitHub officiel de la formation** :

🔗 **Lien du repo :** [Insérer le lien de votre repo GitHub ici]

### 📁 Structure du repo

Le dépôt contient 3 dossiers d'exercices progressifs :

```
formation-s2-dom-async/
├── README.md
├── exercice-1-dom/          # Manipulation DOM
│   ├── index.html
│   ├── style.css
│   └── script.js
├── exercice-2-fetch/        # Fetch API
│   ├── index.html
│   ├── style.css
│   └── script.js
└── mini-projet/             # Projet CRUD complet
    ├── index.html
    ├── style.css
    └── script.js
```

---

### 🎯 Exercice 1 : Liste de Courses Interactive

**Dossier :** `exercice-1-dom/`  
**Durée :** 15 min de pratique + 7 min de correction  
**Concepts :** Manipulation du DOM, événements

**Objectifs :**
- ✅ Ajouter un article à la liste
- ✅ Supprimer un article (clic sur bouton)
- ✅ Barrer/débarrer un article (clic sur l'article)

**Technologies utilisées :**
- HTML/CSS fournis
- JavaScript vanilla (à compléter)
- Aucune dépendance externe

**Instructions :**
1. Clonez le repo GitHub
2. Ouvrez `exercice-1-dom/` avec Live Server
3. Complétez le fichier `script.js`
4. Testez toutes les fonctionnalités
5. Comparez avec la solution du formateur

**Concepts clés pratiqués :**
- `querySelector()` pour sélectionner des éléments
- `createElement()` et `appendChild()` pour créer des éléments
- `addEventListener()` pour gérer les événements
- `classList.toggle()` pour basculer une classe
- `remove()` pour supprimer un élément

---

### 📸 Exercice 2 : Galerie Photos avec Fetch API

**Dossier :** `exercice-2-fetch/`  
**Durée :** 20 min de pratique + 8 min de correction  
**Concepts :** Fetch API, async/await, affichage dynamique

**Objectifs :**
- ✅ Récupérer 6 photos depuis l'API Lorem Picsum
- ✅ Afficher les photos en grille responsive
- ✅ Gérer les états de chargement et les erreurs

**API utilisée :**
- Lorem Picsum : `https://picsum.photos/v2/list?limit=6`
- Aucune clé API nécessaire
- Retourne un tableau d'objets avec `id`, `author`, `download_url`

**Instructions :**
1. Ouvrez `exercice-2-fetch/` avec Live Server
2. Complétez les fonctions dans `script.js` :
   - `createPhotoCard()` : créer une carte pour chaque photo
   - `loadPhotos()` : récupérer et afficher les photos
3. Testez le chargement et la gestion d'erreurs
4. Comparez avec la solution

**Concepts clés pratiqués :**
- `async/await` pour le code asynchrone
- `fetch()` pour les requêtes HTTP
- `response.json()` pour extraire les données
- Gestion d'erreurs avec `try/catch`
- Affichage dynamique dans le DOM

---

### 🚀 Mini-Projet : Gestionnaire de Tâches CRUD

**Dossier :** `mini-projet/`  
**Durée :** 25 min de pratique + 8 min de correction  
**Concepts :** CRUD complet, async/await, gestion d'état

**Objectifs :**
- ✅ **GET** : Récupérer et afficher les tâches au chargement
- ✅ **POST** : Ajouter une nouvelle tâche
- ✅ **PUT** : Marquer une tâche comme complétée/non complétée
- ✅ **DELETE** : Supprimer une tâche
- ✅ Mettre à jour les statistiques en temps réel

**API utilisée :**
- DummyJSON : `https://dummyjson.com/todos`
- Documentation : https://dummyjson.com/docs/todos
- ⚠️ **Important :** Endpoint POST est `/todos/add` et utilise `"todo"` (pas `"title"`)

**Instructions :**
1. Ouvrez `mini-projet/` avec Live Server
2. La fonction `fetchTasks()` (GET) est déjà codée comme exemple
3. Complétez les 3 fonctions TODO :
   - `addTask()` : POST pour créer une tâche
   - `toggleTask()` : PUT pour modifier le statut
   - `deleteTask()` : DELETE pour supprimer
4. Testez toutes les opérations CRUD
5. Vérifiez que les statistiques se mettent à jour

**Concepts clés pratiqués :**
- Toutes les méthodes HTTP (GET, POST, PUT, DELETE)
- Headers et body dans les requêtes
- Gestion d'un tableau d'objets en mémoire
- Mise à jour dynamique de l'interface
- Calcul de statistiques en temps réel

---

### 📝 Comment utiliser le repo GitHub

#### 1. Cloner le repo

```bash
# Cloner le dépôt
git clone [URL_DU_REPO]

# Accéder au dossier
cd formation-s2-dom-async
```

#### 2. Ouvrir avec Live Server

- **VS Code :** Installer l'extension "Live Server", puis clic droit → "Open with Live Server"
- **Autre éditeur :** Ouvrir directement `index.html` dans le navigateur

#### 3. Travailler sur les exercices

- Commencez par l'exercice 1
- Complétez le code dans `script.js`
- Testez au fur et à mesure
- Passez à l'exercice suivant une fois terminé

#### 4. Comparer avec les solutions

Les solutions sont disponibles dans des branches séparées :
- `solution-ex1` : Solution exercice 1
- `solution-ex2` : Solution exercice 2
- `solution-mini-projet` : Solution mini-projet

```bash
# Voir la solution de l'exercice 1
git checkout solution-ex1

# Revenir à la version starter
git checkout main
```

---

### ✅ Checklist de validation

Avant de passer à l'exercice suivant, assurez-vous que :

**Exercice 1 :**
- [ ] L'ajout d'article fonctionne
- [ ] Le clic sur l'article le barre/débarre
- [ ] Le bouton supprimer fonctionne
- [ ] L'input se vide après ajout
- [ ] Pas d'erreurs dans la console

**Exercice 2 :**
- [ ] Les 6 photos se chargent correctement
- [ ] Le message de chargement apparaît
- [ ] Les photos s'affichent en grille
- [ ] Les erreurs sont gérées
- [ ] Pas d'erreurs dans la console

**Mini-Projet :**
- [ ] Les tâches se chargent au démarrage (GET)
- [ ] L'ajout de tâche fonctionne (POST)
- [ ] La checkbox modifie le statut (PUT)
- [ ] La suppression fonctionne (DELETE)
- [ ] Les statistiques se mettent à jour
- [ ] Toutes les erreurs sont gérées

---

### 💡 Conseils pour réussir

1. **Lisez d'abord tout le code fourni** avant de commencer à coder
2. **Testez après chaque modification** - ne codez pas tout d'un coup
3. **Utilisez `console.log()`** pour déboguer
4. **Consultez la documentation** si besoin (MDN Web Docs)
5. **N'hésitez pas à demander de l'aide** pendant la session
6. **Comparez avec les solutions** seulement après avoir essayé

---

### 🔗 Ressources utiles pendant les exercices

- **MDN querySelector** : https://developer.mozilla.org/fr/docs/Web/API/Document/querySelector
- **MDN addEventListener** : https://developer.mozilla.org/fr/docs/Web/API/EventTarget/addEventListener
- **MDN Fetch API** : https://developer.mozilla.org/fr/docs/Web/API/Fetch_API
- **Lorem Picsum Docs** : https://picsum.photos/
- **DummyJSON Docs** : https://dummyjson.com/docs/todos

---

---

## Ressources Supplémentaires

### 📖 Documentation officielle
- **MDN Web Docs** : https://developer.mozilla.org/fr/
  - La meilleure documentation JavaScript
  - Exemples clairs et complets
  
- **JavaScript.info** : https://javascript.info
  - Tutoriels modernes et détaillés
  - Excellent pour approfondir

### 🎮 Pratique interactive
- **FreeCodeCamp** : https://freecodecamp.org
  - Cours gratuits avec certificats
  - Projets pratiques

- **Exercism** : https://exercism.org/tracks/javascript
  - Exercices avec mentorat
  - Progression par niveau

### 🔧 Outils utiles
- **JSONPlaceholder** : https://jsonplaceholder.typicode.com
  - API gratuite pour tester
  - Parfaite pour l'apprentissage

- **CodePen** : https://codepen.io
  - Tester rapidement du code
  - Partager vos créations

### 📺 Chaînes YouTube (en français)
- **Grafikart**
- **From Scratch**
- **Underscore_**

### 💡 Conseils pour progresser

1. **Pratiquez régulièrement**
   - Codez tous les jours, même 15 minutes
   - Refaites les exercices de mémoire

2. **Lisez du code**
   - Explorez GitHub
   - Analysez comment les autres codent

3. **Construisez des projets**
   - Todo list, météo app, quiz app
   - Mettez-les sur GitHub

4. **Déboguez vous-même**
   - Utilisez console.log
   - Utilisez les DevTools du navigateur

5. **Posez des questions**
   - Stack Overflow
   - Discord/Slack de développeurs
   - Forums spécialisés

---

## 🎓 Récapitulatif Final

### Ce que vous avez appris

#### Manipulation du DOM
- ✅ Sélectionner des éléments avec `querySelector`
- ✅ Modifier le contenu avec `textContent` et `innerHTML`
- ✅ Gérer les classes avec `classList`
- ✅ Créer et supprimer des éléments
- ✅ Écouter et réagir aux événements

#### Programmation Asynchrone
- ✅ Comprendre les Promises
- ✅ Utiliser async/await
- ✅ Effectuer des requêtes avec Fetch API
- ✅ Implémenter les opérations CRUD
- ✅ Gérer les erreurs correctement

### Prochaines étapes

Maintenant que vous maîtrisez les bases, voici ce que vous pouvez explorer :

1. **Framework JavaScript moderne**
   - React, Vue.js ou Angular
   - Construire des applications plus complexes

2. **Backend avec Node.js**
   - Créer vos propres APIs
   - Connecter à une vraie base de données

3. **Gestion d'état**
   - Redux, Vuex, Context API
   - Gérer des états complexes

4. **TypeScript**
   - JavaScript typé
   - Moins d'erreurs, meilleur code

5. **Tests**
   - Jest, Cypress
   - Tester votre code automatiquement

---

## 📝 Exercices Supplémentaires pour Pratiquer

### Exercice Bonus 1 : Calculatrice Simple

**Objectif :** Créer une calculatrice fonctionnelle en utilisant la manipulation du DOM.

**Fonctionnalités à implémenter :**
- Interface avec boutons 0-9, +, -, ×, ÷, =
- Affichage du calcul en cours
- Gestion des erreurs (division par zéro)
- Bouton clear pour tout effacer

**HTML de départ :**
```html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Calculatrice</title>
    <style>
        .calculatrice {
            max-width: 300px;
            margin: 50px auto;
            padding: 20px;
            background: #f0f0f0;
            border-radius: 10px;
        }
        
        .affichage {
            background: white;
            padding: 20px;
            text-align: right;
            font-size: 24px;
            border-radius: 5px;
            margin-bottom: 10px;
            min-height: 50px;
        }
        
        .boutons {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        
        button {
            padding: 20px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            background: white;
        }
        
        button:hover {
            background: #e0e0e0;
        }
        
        .operateur {
            background: #ff9500;
            color: white;
        }
        
        .operateur:hover {
            background: #cc7700;
        }
    </style>
</head>
<body>
    <div class="calculatrice">
        <div class="affichage" id="affichage">0</div>
        <div class="boutons">
            <button onclick="ajouterChiffre('7')">7</button>
            <button onclick="ajouterChiffre('8')">8</button>
            <button onclick="ajouterChiffre('9')">9</button>
            <button class="operateur" onclick="ajouterOperateur('/')">÷</button>
            
            <button onclick="ajouterChiffre('4')">4</button>
            <button onclick="ajouterChiffre('5')">5</button>
            <button onclick="ajouterChiffre('6')">6</button>
            <button class="operateur" onclick="ajouterOperateur('*')">×</button>
            
            <button onclick="ajouterChiffre('1')">1</button>
            <button onclick="ajouterChiffre('2')">2</button>
            <button onclick="ajouterChiffre('3')">3</button>
            <button class="operateur" onclick="ajouterOperateur('-')">-</button>
            
            <button onclick="ajouterChiffre('0')">0</button>
            <button onclick="effacer()">C</button>
            <button onclick="calculer()">=</button>
            <button class="operateur" onclick="ajouterOperateur('+')">+</button>
        </div>
    </div>
    
    <script src="calculatrice.js"></script>
</body>
</html>
```

**JavaScript à compléter :**
```javascript
let affichage = document.querySelector('#affichage');
let calcul = '';

function ajouterChiffre(chiffre) {
    if (calcul === '0') {
        calcul = chiffre;
    } else {
        calcul += chiffre;
    }
    affichage.textContent = calcul;
}

function ajouterOperateur(operateur) {
    calcul += ' ' + operateur + ' ';
    affichage.textContent = calcul;
}

function calculer() {
    try {
        const resultat = eval(calcul);
        affichage.textContent = resultat;
        calcul = resultat.toString();
    } catch (error) {
        affichage.textContent = 'Erreur';
        calcul = '';
    }
}

function effacer() {
    calcul = '0';
    affichage.textContent = '0';
}
```

---

### Exercice Bonus 2 : Application Météo avec API

**Objectif :** Créer une application qui affiche la météo d'une ville en utilisant une API gratuite.

**API gratuite à utiliser :**
- OpenWeatherMap : https://openweathermap.org/api
- Inscription gratuite pour obtenir une clé API

**Fonctionnalités :**
- Rechercher une ville
- Afficher température, description, icône météo
- Gérer les erreurs (ville non trouvée)

**HTML de départ :**
```html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Application Météo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to bottom, #00c6ff, #0072ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }
        
        .container {
            background: white;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 10px 50px rgba(0,0,0,0.3);
            max-width: 400px;
            width: 100%;
        }
        
        h1 {
            text-align: center;
            color: #333;
        }
        
        .recherche {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        input {
            flex: 1;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        button {
            padding: 10px 20px;
            background: #0072ff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        
        button:hover {
            background: #0056b3;
        }
        
        .meteo {
            text-align: center;
        }
        
        .ville {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .temperature {
            font-size: 48px;
            font-weight: bold;
            color: #0072ff;
        }
        
        .description {
            font-size: 20px;
            color: #666;
            margin-top: 10px;
        }
        
        .icone {
            font-size: 80px;
        }
        
        .loading {
            text-align: center;
            color: #666;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        
        .hide {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌤️ Météo</h1>
        
        <div class="recherche">
            <input 
                type="text" 
                id="ville" 
                placeholder="Entrez une ville..."
            >
            <button id="btnRechercher">Rechercher</button>
        </div>
        
        <div id="loading" class="loading hide">
            Chargement...
        </div>
        
        <div id="error" class="error hide"></div>
        
        <div id="meteo" class="meteo hide">
            <div class="icone" id="icone">☀️</div>
            <div class="ville" id="nomVille"></div>
            <div class="temperature" id="temperature"></div>
            <div class="description" id="description"></div>
        </div>
    </div>
    
    <script src="meteo.js"></script>
</body>
</html>
```

**JavaScript :**
```javascript
// Remplacez par votre clé API OpenWeatherMap
const API_KEY = 'VOTRE_CLE_API';
const API_URL = 'https://api.openweathermap.org/data/2.5/weather';

const inputVille = document.querySelector('#ville');
const btnRechercher = document.querySelector('#btnRechercher');
const loading = document.querySelector('#loading');
const error = document.querySelector('#error');
const meteo = document.querySelector('#meteo');

const nomVille = document.querySelector('#nomVille');
const temperature = document.querySelector('#temperature');
const description = document.querySelector('#description');
const icone = document.querySelector('#icone');

async function rechercherMeteo() {
    const ville = inputVille.value.trim();
    
    if (ville === '') {
        afficherErreur('Veuillez entrer une ville');
        return;
    }
    
    // Afficher le chargement
    loading.classList.remove('hide');
    meteo.classList.add('hide');
    error.classList.add('hide');
    
    try {
        const url = `${API_URL}?q=${ville}&appid=${API_KEY}&units=metric&lang=fr`;
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error('Ville non trouvée');
        }
        
        const data = await response.json();
        
        // Afficher les données
        afficherMeteo(data);
        
    } catch (err) {
        afficherErreur('Impossible de trouver cette ville');
    } finally {
        loading.classList.add('hide');
    }
}

function afficherMeteo(data) {
    nomVille.textContent = data.name;
    temperature.textContent = `${Math.round(data.main.temp)}°C`;
    description.textContent = data.weather[0].description;
    
    // Choisir l'icône selon la météo
    const weatherCode = data.weather[0].main;
    const icones = {
        'Clear': '☀️',
        'Clouds': '☁️',
        'Rain': '🌧️',
        'Snow': '❄️',
        'Thunderstorm': '⛈️',
        'Drizzle': '🌦️',
        'Mist': '🌫️'
    };
    icone.textContent = icones[weatherCode] || '🌤️';
    
    meteo.classList.remove('hide');
}

function afficherErreur(message) {
    error.textContent = message;
    error.classList.remove('hide');
    meteo.classList.add('hide');
}

// Événements
btnRechercher.addEventListener('click', rechercherMeteo);

inputVille.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        rechercherMeteo();
    }
});
```

---

### Exercice Bonus 3 : Quiz Interactif

**Objectif :** Créer un quiz avec score et feedback.

**HTML de départ :**
```html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Quiz JavaScript</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        
        .quiz-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        h1 {
            text-align: center;
            color: #333;
        }
        
        .question {
            font-size: 20px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        
        .options {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .option {
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .option:hover {
            background: #f0f0f0;
        }
        
        .option.correct {
            background: #d4edda;
            border-color: #28a745;
        }
        
        .option.incorrect {
            background: #f8d7da;
            border-color: #dc3545;
        }
        
        .option.disabled {
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        
        button {
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        
        button:hover {
            background: #0056b3;
        }
        
        button:disabled {
            background: #ccc;
            cursor: not-allowed;
        }
        
        .score {
            text-align: center;
            font-size: 24px;
            margin-top: 20px;
        }
        
        .resultat {
            text-align: center;
            font-size: 20px;
            padding: 20px;
            background: #d4edda;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="quiz-container">
        <h1>Quiz JavaScript</h1>
        
        <div id="quiz">
            <div class="question" id="question"></div>
            <div class="options" id="options"></div>
            
            <div class="buttons">
                <button id="btnPrecedent" disabled>Précédent</button>
                <div class="score">
                    Question <span id="numQuestion">1</span> sur <span id="totalQuestions">5</span>
                </div>
                <button id="btnSuivant">Suivant</button>
            </div>
        </div>
        
        <div id="resultat" class="resultat" style="display: none;">
            <h2>Quiz terminé !</h2>
            <p>Votre score : <span id="scoreF inal"></span></p>
            <button id="btnRecommencer">Recommencer</button>
        </div>
    </div>
    
    <script src="quiz.js"></script>
</body>
</html>
```

**JavaScript :**
```javascript
// Questions du quiz
const questions = [
    {
        question: "Que signifie DOM ?",
        options: [
            "Document Object Model",
            "Data Object Management",
            "Digital Online Method",
            "Document Oriented Model"
        ],
        correct: 0
    },
    {
        question: "Quelle méthode est utilisée pour sélectionner un élément par son ID ?",
        options: [
            "getElement()",
            "querySelector()",
            "selectById()",
            "findElement()"
        ],
        correct: 1
    },
    {
        question: "Que fait la méthode addEventListener() ?",
        options: [
            "Supprime un événement",
            "Crée un nouvel élément",
            "Écoute un événement",
            "Modifie le DOM"
        ],
        correct: 2
    },
    {
        question: "Quelle méthode est utilisée pour les requêtes HTTP en JavaScript moderne ?",
        options: [
            "XMLHttpRequest",
            "fetch()",
            "ajax()",
            "httpRequest()"
        ],
        correct: 1
    },
    {
        question: "Que signifie 'async' devant une fonction ?",
        options: [
            "La fonction est synchrone",
            "La fonction retourne une Promise",
            "La fonction est plus rapide",
            "La fonction ne peut pas utiliser await"
        ],
        correct: 1
    }
];

let questionActuelle = 0;
let score = 0;
let reponses = new Array(questions.length).fill(null);

const questionElement = document.querySelector('#question');
const optionsElement = document.querySelector('#options');
const btnPrecedent = document.querySelector('#btnPrecedent');
const btnSuivant = document.querySelector('#btnSuivant');
const numQuestion = document.querySelector('#numQuestion');
const totalQuestions = document.querySelector('#totalQuestions');
const resultat = document.querySelector('#resultat');
const scoreFinal = document.querySelector('#scoreFinal');
const btnRecommencer = document.querySelector('#btnRecommencer');
const quiz = document.querySelector('#quiz');

// Initialiser
totalQuestions.textContent = questions.length;
afficherQuestion();

function afficherQuestion() {
    const q = questions[questionActuelle];
    
    questionElement.textContent = q.question;
    optionsElement.innerHTML = '';
    
    q.options.forEach((option, index) => {
        const div = document.createElement('div');
        div.className = 'option';
        div.textContent = option;
        
        // Si déjà répondu, afficher le résultat
        if (reponses[questionActuelle] !== null) {
            div.classList.add('disabled');
            if (index === q.correct) {
                div.classList.add('correct');
            } else if (index === reponses[questionActuelle]) {
                div.classList.add('incorrect');
            }
        } else {
            // Sinon, permettre de cliquer
            div.addEventListener('click', () => selectionnerOption(index));
        }
        
        optionsElement.appendChild(div);
    });
    
    // Mettre à jour les boutons
    numQuestion.textContent = questionActuelle + 1;
    btnPrecedent.disabled = questionActuelle === 0;
    
    if (questionActuelle === questions.length - 1) {
        btnSuivant.textContent = 'Terminer';
    } else {
        btnSuivant.textContent = 'Suivant';
    }
}

function selectionnerOption(index) {
    const q = questions[questionActuelle];
    reponses[questionActuelle] = index;
    
    // Vérifier si correct
    if (index === q.correct) {
        score++;
    }
    
    // Désactiver toutes les options
    const options = document.querySelectorAll('.option');
    options.forEach((opt, i) => {
        opt.classList.add('disabled');
        if (i === q.correct) {
            opt.classList.add('correct');
        } else if (i === index) {
            opt.classList.add('incorrect');
        }
    });
}

function questionSuivante() {
    if (reponses[questionActuelle] === null) {
        alert('Veuillez sélectionner une réponse');
        return;
    }
    
    if (questionActuelle < questions.length - 1) {
        questionActuelle++;
        afficherQuestion();
    } else {
        afficherResultat();
    }
}

function questionPrecedente() {
    if (questionActuelle > 0) {
        questionActuelle--;
        afficherQuestion();
    }
}

function afficherResultat() {
    quiz.style.display = 'none';
    resultat.style.display = 'block';
    
    const pourcentage = Math.round((score / questions.length) * 100);
    scoreFinal.textContent = `${score} / ${questions.length} (${pourcentage}%)`;
}

function recommencer() {
    questionActuelle = 0;
    score = 0;
    reponses = new Array(questions.length).fill(null);
    
    quiz.style.display = 'block';
    resultat.style.display = 'none';
    
    afficherQuestion();
}

// Événements
btnSuivant.addEventListener('click', questionSuivante);
btnPrecedent.addEventListener('click', questionPrecedente);
btnRecommencer.addEventListener('click', recommencer);
```

---

## 🎯 Projets Finaux Suggérés

Pour consolider vos compétences, voici quelques projets complets à réaliser :

### 1. Application de Notes (Clone de Google Keep)
**Fonctionnalités :**
- Créer, modifier, supprimer des notes
- Recherche dans les notes
- Catégories/tags
- Sauvegarde en localStorage

### 2. Gestionnaire de Dépenses
**Fonctionnalités :**
- Ajouter revenus et dépenses
- Catégoriser les transactions
- Graphiques de visualisation
- Calcul du solde

### 3. Application de Citations Aléatoires
**Fonctionnalités :**
- Récupérer des citations depuis une API
- Bouton "Nouvelle citation"
- Partage sur réseaux sociaux
- Sauvegarde des favoris

### 4. Jeu du Pendu
**Fonctionnalités :**
- Interface graphique du pendu
- Sélection de catégories
- Système de vies
- Score et historique

### 5. Convertisseur Multi-devises
**Fonctionnalités :**
- API de taux de change en temps réel
- Conversion entre plusieurs devises
- Historique des conversions
- Graphique d'évolution

---

## 📌 Antisèches Rapides

### Sélecteurs DOM
```javascript
// Un seul élément
document.querySelector('#id')
document.querySelector('.classe')
document.querySelector('div')

// Plusieurs éléments
document.querySelectorAll('.classe')
```

### Manipulation
```javascript
// Contenu
element.textContent = "texte"
element.innerHTML = "<strong>HTML</strong>"
element.value = "valeur input"

// Style
element.classList.add('classe')
element.classList.remove('classe')
element.classList.toggle('classe')

// Création
const div = document.createElement('div')
parent.appendChild(div)
element.remove()
```

### Événements
```javascript
element.addEventListener('click', () => {})
element.addEventListener('input', () => {})
form.addEventListener('submit', (e) => {
    e.preventDefault()
})
```

### Fetch API
```javascript
// GET
const response = await fetch(url)
const data = await response.json()

// POST
const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
})

// PUT
const response = await fetch(`${url}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
})

// DELETE
await fetch(`${url}/${id}`, { method: 'DELETE' })
```

### Async/Await
```javascript
async function maFonction() {
    try {
        const result = await promesse()
        return result
    } catch (error) {
        console.error(error)
    }
}
```

---

## ✅ Checklist de Maîtrise

Cochez ce que vous savez faire sans aide :

**DOM :**
- [ ] Sélectionner un élément par ID, classe, balise
- [ ] Modifier le texte d'un élément
- [ ] Ajouter/retirer des classes CSS
- [ ] Créer un nouvel élément
- [ ] Supprimer un élément
- [ ] Écouter un événement (clic, input, submit)
- [ ] Empêcher le comportement par défaut

**Asynchrone :**
- [ ] Comprendre ce qu'est une Promise
- [ ] Utiliser async/await
- [ ] Faire une requête GET
- [ ] Faire une requête POST
- [ ] Gérer les erreurs avec try/catch
- [ ] Vérifier le statut de la réponse

**Projet :**
- [ ] Créer une application CRUD complète
- [ ] Gérer les erreurs utilisateur
- [ ] Valider un formulaire
- [ ] Afficher des messages de chargement

---

## 🎓 Conclusion

Félicitations ! Vous avez maintenant toutes les bases nécessaires pour créer des applications web interactives et dynamiques.

**Les points clés à retenir :**

1. **Le DOM est votre ami** - Tout est question de sélectionner et manipuler des éléments
2. **Async/Await simplifie la vie** - Plus besoin de callbacks complexes
3. **Fetch est puissant** - Toutes les opérations CRUD sont possibles
4. **La pratique est essentielle** - Codez, cassez, réparez, apprenez

**Prochaines actions recommandées :**

1. ✅ Refaire les 3 exercices de mémoire
2. ✅ Créer un projet personnel
3. ✅ Explorer une API publique intéressante
4. ✅ Partager votre code sur GitHub
5. ✅ Aider d'autres étudiants à apprendre

---

**Bon courage dans votre apprentissage ! 💪**

**Questions ? Contactez-nous sur le groupe WhatsApp du club.**

**Happy coding! 🚀**
