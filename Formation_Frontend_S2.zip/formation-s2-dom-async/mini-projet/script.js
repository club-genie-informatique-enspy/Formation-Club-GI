/**
 * MINI-PROJET - GESTIONNAIRE DE TÂCHES
 * 
 * Application CRUD complète avec DummyJSON API
 * 
 * VERSION STARTER : Les fonctions utilitaires et d'affichage sont complètes.
 * Les participants complètent les 4 fonctions CRUD principales.
 */

// ==========================================
// SÉLECTION DES ÉLÉMENTS (DÉJÀ FAIT)
// ==========================================

const taskInput = document.querySelector('#taskInput');
const addTaskBtn = document.querySelector('#addTaskBtn');
const tasksList = document.querySelector('#tasksList');
const loadingState = document.querySelector('#loadingState');
const errorState = document.querySelector('#errorState');
const retryBtn = document.querySelector('#retryBtn');

// Compteurs
const totalTasksEl = document.querySelector('#totalTasks');
const completedTasksEl = document.querySelector('#completedTasks');
const pendingTasksEl = document.querySelector('#pendingTasks');

// Configuration API
const API_URL = 'https://dummyjson.com/todos';
const LIMIT = 10; // Nombre de tâches à charger

// Tableau pour stocker les tâches localement
let tasks = [];


// ==========================================
// FONCTIONS UTILITAIRES (DÉJÀ COMPLÉTÉES)
// ==========================================

function toggleLoading(show) {
    if (show) {
        loadingState.classList.remove('hidden');
        tasksList.innerHTML = '';
    } else {
        loadingState.classList.add('hidden');
    }
}

function toggleError(show) {
    if (show) {
        errorState.classList.remove('hidden');
        tasksList.innerHTML = '';
    } else {
        errorState.classList.add('hidden');
    }
}

function updateStats() {
    const total = tasks.length;
    const completed = tasks.filter(task => task.completed).length;
    const pending = total - completed;
    
    totalTasksEl.textContent = total;
    completedTasksEl.textContent = completed;
    pendingTasksEl.textContent = pending;
}

function createTaskElement(task) {
    const taskItem = document.createElement('div');
    taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
    taskItem.dataset.id = task.id;
    
    // IMPORTANT : DummyJSON utilise "todo" au lieu de "title"
    taskItem.innerHTML = `
        <input 
            type="checkbox" 
            class="task-checkbox" 
            ${task.completed ? 'checked' : ''}
        >
        <span class="task-text">${task.todo}</span>
        <span class="task-id">#${task.id}</span>
        <button class="btn-delete">🗑️ Supprimer</button>
    `;
    
    const checkbox = taskItem.querySelector('.task-checkbox');
    const deleteBtn = taskItem.querySelector('.btn-delete');
    
    checkbox.addEventListener('change', () => toggleTask(task.id));
    deleteBtn.addEventListener('click', () => deleteTask(task.id));
    
    return taskItem;
}

function renderTasks() {
    tasksList.innerHTML = '';
    
    tasks.forEach(task => {
        const taskElement = createTaskElement(task);
        tasksList.appendChild(taskElement);
    });
    
    updateStats();
}


// ==========================================
// PARTIE 1 : RÉCUPÉRER LES TÂCHES (GET)
// CODE ENSEMBLE PENDANT LA FORMATION
// ==========================================

async function fetchTasks() {
    toggleLoading(true);
    toggleError(false);
    
    try {
        const response = await fetch(`${API_URL}?limit=${LIMIT}`);
        
        if (!response.ok) {
            throw new Error('Erreur réseau');
        }
        
        const data = await response.json();
        
        // IMPORTANT : DummyJSON retourne { todos: [...], total, skip, limit }
        // On récupère le tableau "todos"
        tasks = data.todos;
        renderTasks();
        
    } catch (error) {
        console.error('Erreur:', error);
        toggleError(true);
    } finally {
        toggleLoading(false);
    }
}


// ==========================================
// TODO 1 : AJOUTER UNE TÂCHE (POST)
// À COMPLÉTER PAR LES PARTICIPANTS
// ==========================================

async function addTask() {
    // TODO: Récupérer la valeur de l'input
    const todoText = null; // TODO: Récupérer taskInput.value.trim()
    
    // TODO: Vérifier que l'input n'est pas vide
    if (!todoText) {
        alert('Veuillez entrer une tâche');
        return;
    }
    
    try {
        // TODO: Faire la requête POST
        // IMPORTANT : DummyJSON utilise l'endpoint /todos/add
        // Structure du body :
        // {
        //   todo: todoText,  (pas "title" !)
        //   completed: false,
        //   userId: 1
        // }
        
        const response = null; // TODO: Complétez avec fetch(`${API_URL}/add`, {...})
        
        // TODO: Convertir la réponse en JSON
        const newTask = null; // TODO: await response.json()
        
        // TODO: Ajouter la nouvelle tâche au début du tableau tasks
        // Utilisez unshift() pour ajouter au début
        
        
        // TODO: Afficher les tâches
        
        
        // TODO: Vider l'input et remettre le focus
        
        
    } catch (error) {
        console.error('Erreur lors de l\'ajout:', error);
        alert('Impossible d\'ajouter la tâche');
    }
}


// ==========================================
// TODO 2 : MARQUER UNE TÂCHE COMME COMPLÉTÉE (PUT)
// À COMPLÉTER PAR LES PARTICIPANTS
// ==========================================

async function toggleTask(taskId) {
    // TODO: Trouver la tâche dans le tableau tasks
    const task = null; // TODO: Utilisez tasks.find(t => t.id === taskId)
    
    if (!task) return;
    
    try {
        // TODO: Faire la requête PUT
        // URL: `${API_URL}/${taskId}`
        // Body: { completed: !task.completed }
        
        const response = null; // TODO: Complétez avec fetch(...)
        
        // TODO: Mettre à jour l'état local de la tâche
        
        
        // TODO: Réafficher les tâches
        
        
    } catch (error) {
        console.error('Erreur lors de la mise à jour:', error);
    }
}


// ==========================================
// TODO 3 : SUPPRIMER UNE TÂCHE (DELETE)
// À COMPLÉTER PAR LES PARTICIPANTS
// ==========================================

async function deleteTask(taskId) {
    // TODO: Demander confirmation
    if (!confirm('Voulez-vous vraiment supprimer cette tâche ?')) {
        return;
    }
    
    try {
        // TODO: Faire la requête DELETE
        // URL: `${API_URL}/${taskId}`
        
        const response = null; // TODO: Complétez avec fetch(...)
        
        // TODO: Retirer la tâche du tableau tasks
        // Utilisez filter() pour garder toutes les tâches sauf celle-ci
        tasks = null; // TODO: tasks.filter(task => task.id !== taskId)
        
        // TODO: Réafficher les tâches
        
        
    } catch (error) {
        console.error('Erreur lors de la suppression:', error);
        alert('Impossible de supprimer la tâche');
    }
}


// ==========================================
// EVENT LISTENERS (DÉJÀ FAIT)
// ==========================================

addTaskBtn.addEventListener('click', addTask);

taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        addTask();
    }
});

retryBtn.addEventListener('click', fetchTasks);


// ==========================================
// INITIALISATION (DÉJÀ FAIT)
// ==========================================

fetchTasks();


// ==========================================
// 🎉 FÉLICITATIONS !
// ==========================================
/**
 * Une fois terminé, vous aurez créé une application CRUD complète !
 * 
 * POINTS IMPORTANTS DUMMYJSON :
 * - Endpoint POST : /todos/add (pas juste /todos)
 * - Champ texte : "todo" (pas "title")
 * - Réponse GET : { todos: [...], total, skip, limit }
 * 
 * PROCHAINES ÉTAPES :
 * 1. Tester toutes les fonctionnalités avec Live Server
 * 2. Commit : git add . && git commit -m "Mini-projet terminé"
 * 3. Push : git push origin main
 * 
 * AMÉLIORATIONS POSSIBLES :
 * - Filtrer les tâches (toutes/complétées/en cours)
 * - Recherche par texte
 * - LocalStorage pour persistance
 * - Mode sombre
 */