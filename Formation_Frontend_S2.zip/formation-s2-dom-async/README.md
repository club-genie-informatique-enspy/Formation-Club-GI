# 🚀 Formation S2 : Asynchrone et DOM

**Club Génie Informatique - ENSPY**  
Formation sur la manipulation du DOM et la programmation asynchrone en JavaScript

---

## 📋 Contenu

Ce repo contient 3 exercices progressifs :

1. **Exercice 1 : Liste de Courses** - Manipulation DOM
2. **Exercice 2 : Galerie Photos** - Fetch API
3. **Mini-Projet : Gestionnaire de Tâches** - Application CRUD complète

---

## 🛠️ Prérequis

Avant de commencer, assurez-vous d'avoir :

- ✅ Un navigateur moderne (Chrome/Firefox)
- ✅ Visual Studio Code avec Live Server
- ✅ Git installé et configuré
- ✅ Un compte GitHub

📄 [Guide d'installation complet](lien-vers-pdf-prerequis)

---

## 🚀 Installation

### Méthode 1 : Cloner avec Git (recommandé)

```bash
# Cloner le repo
git clone https://github.com/VOTRE-USERNAME/formation-s2-dom-async.git

# Entrer dans le dossier
cd formation-s2-dom-async
```

### Méthode 2 : Télécharger le ZIP

1. Cliquer sur le bouton vert **"Code"**
2. Sélectionner **"Download ZIP"**
3. Extraire le fichier
4. Ouvrir le dossier dans VS Code

---

## 📂 Structure du Projet

```
formation-s2-dom-async/
│
├── exercice-1-dom/
│   ├── index.html          # Structure HTML
│   ├── style.css           # Styles fournis
│   └── script.js           # À compléter
│
├── exercice-2-fetch/
│   ├── index.html          # Structure HTML
│   ├── style.css           # Styles fournis
│   └── script.js           # À compléter
│
├── mini-projet/
│   ├── index.html          # Structure HTML
│   ├── style.css           # Styles fournis
│   └── script.js           # À compléter
│
└── README.md               # Ce fichier
```

---

## 🎯 Exercice 1 : Liste de Courses

### Objectif
Créer une liste de courses interactive avec ajout, suppression et barre d'articles.

### Fonctionnalités à implémenter
- Ajouter un article à la liste
- Supprimer un article au clic
- Barrer un article quand on clique dessus

### Lancer l'exercice
1. Ouvrir `exercice-1-dom/index.html` dans VS Code
2. **Clic droit → "Open with Live Server"** ⚠️ IMPORTANT
3. Compléter les TODO dans `script.js`

> ⚠️ **ATTENTION :** N'ouvrez PAS les fichiers HTML directement dans le navigateur (double-clic).
> Utilisez toujours Live Server pour éviter les problèmes CORS avec les APIs.

### Durée estimée
20 minutes

---

## 🎯 Exercice 2 : Galerie Photos

### Objectif
Afficher une galerie de photos récupérées depuis une API.

### API utilisée
`https://picsum.photos/v2/list?page=1&limit=9`

**Lorem Picsum** - API gratuite de photos placeholder de haute qualité

### Fonctionnalités à implémenter
- Récupérer 9 photos depuis l'API
- Créer une carte pour chaque photo
- Afficher le titre et l'image
- Gérer les erreurs

### Lancer l'exercice
1. Ouvrir `exercice-2-fetch/index.html` dans VS Code
2. **Clic droit → "Open with Live Server"** ⚠️ IMPORTANT
3. Compléter les TODO dans `script.js`

> ⚠️ **ATTENTION :** N'ouvrez PAS les fichiers HTML directement dans le navigateur.
> Utilisez toujours Live Server pour que les requêtes API fonctionnent correctement.

### Durée estimée
30 minutes

---

## 🎯 Mini-Projet : Gestionnaire de Tâches

### Objectif
Créer une application CRUD complète pour gérer des tâches.

### API utilisée
`https://jsonplaceholder.typicode.com/todos`

### Fonctionnalités à implémenter
- ✅ Récupérer et afficher les tâches (GET)
- ➕ Ajouter une nouvelle tâche (POST)
- ✔️ Marquer une tâche comme complétée (PUT)
- 🗑️ Supprimer une tâche (DELETE)

### Lancer le projet
1. Ouvrir `mini-projet/index.html` dans VS Code
2. **Clic droit → "Open with Live Server"** ⚠️ IMPORTANT
3. Compléter les TODO dans `script.js`

> ⚠️ **ATTENTION :** N'ouvrez PAS les fichiers HTML directement dans le navigateur.
> Utilisez toujours Live Server pour que les requêtes API fonctionnent correctement.

### Durée estimée
30 minutes

---

## 📚 Ressources Utiles

### Documentation
- [MDN Web Docs](https://developer.mozilla.org/fr/) - Documentation complète JS
- [JavaScript.info](https://javascript.info) - Tutoriels détaillés
- [JSONPlaceholder](https://jsonplaceholder.typicode.com/) - API de test gratuite

### DOM
- [querySelector](https://developer.mozilla.org/fr/docs/Web/API/Document/querySelector)
- [addEventListener](https://developer.mozilla.org/fr/docs/Web/API/EventTarget/addEventListener)
- [createElement](https://developer.mozilla.org/fr/docs/Web/API/Document/createElement)

### Fetch API
- [Fetch API](https://developer.mozilla.org/fr/docs/Web/API/Fetch_API)
- [Async/Await](https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Statements/async_function)
- [Promises](https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Promise)

---

## 🐛 Résolution de Problèmes

### Live Server ne fonctionne pas
- Vérifier que l'extension est installée dans VS Code
- Redémarrer VS Code
- Clic droit sur le fichier HTML → "Open with Live Server"

### Fetch ne fonctionne pas
- Vérifier la console pour les erreurs
- S'assurer d'être dans une fonction `async`
- Vérifier l'URL de l'API
- Tester l'API dans le navigateur directement

### Git : erreur "not a git repository"
```bash
# Initialiser Git dans le dossier
git init

# Ajouter les fichiers
git add .

# Premier commit
git commit -m "Initial commit"
```

---

## 🤝 Contributions

Des suggestions ? Des bugs trouvés ?

1. Ouvrir une issue sur GitHub
2. Proposer une Pull Request
3. Contacter la cellule formation sur WhatsApp

---

## 📝 Commits Recommandés

Après chaque exercice terminé, commiter vos changements :

```bash
# Exercice 1
git add exercice-1-dom/
git commit -m "Exercice 1: Liste de courses terminée"

# Exercice 2
git add exercice-2-fetch/
git commit -m "Exercice 2: Galerie photos terminée"

# Mini-projet
git add mini-projet/
git commit -m "Mini-projet: Gestionnaire de tâches terminé"

# Push vers GitHub
git push origin main
```

---

## 📧 Contact

**Club Génie Informatique - ENSPY**  
📱 Groupe WhatsApp : [Lien du groupe]  
📧 Email : clubgi@enspy.cm  
🌐 Site web : [À venir]

---

## 📄 Licence

Ce projet est sous licence MIT - libre d'utilisation à des fins éducatives.

---

**Bonne formation ! 🎓💻**