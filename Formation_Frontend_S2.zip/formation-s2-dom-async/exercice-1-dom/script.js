/**
 * EXERCICE 1 - LISTE DE COURSES
 * 
 * Objectif : Créer une liste de courses interactive
 * 
 * Fonctionnalités à implémenter :
 * 1. Ajouter un article à la liste
 * 2. Supprimer un article (clic sur le bouton ❌)
 * 3. Barrer/débarrer un article (clic sur l'article)
 * 4. Mettre à jour le compteur d'articles
 */

// ==========================================
// TODO 1 : SÉLECTIONNER LES ÉLÉMENTS DU DOM
// ==========================================
// Sélectionnez les éléments suivants avec querySelector :
// - L'input (id: itemInput)
// - Le bouton ajouter (id: addBtn)
// - La liste ul (id: shoppingList)
// - Le compteur (id: totalItems)

// Exemple : const monElement = document.querySelector('#monId');

const itemInput = null; // TODO: Remplacer null par la sélection
const addBtn = null;    // TODO: Remplacer null par la sélection
const shoppingList = null; // TODO: Remplacer null par la sélection
const totalItems = null;   // TODO: Remplacer null par la sélection


// ==========================================
// TODO 2 : FONCTION POUR AJOUTER UN ARTICLE
// ==========================================
/**
 * Cette fonction doit :
 * 1. Récupérer la valeur de l'input
 * 2. Vérifier qu'elle n'est pas vide
 * 3. Créer un nouvel élément <li>
 * 4. Ajouter le HTML nécessaire (texte + bouton supprimer)
 * 5. Ajouter des event listeners sur le li et le bouton
 * 6. Ajouter le li à la liste
 * 7. Vider l'input
 * 8. Mettre à jour le compteur
 */

function addItem() {
    // TODO: Récupérer la valeur de l'input
    const itemText = ''; // Complétez ici
    
    // TODO: Vérifier que l'input n'est pas vide
    // Si vide, faire un return et ne rien ajouter
    
    
    // TODO: Créer un élément <li>
    const li = null; // Utilisez document.createElement() à la place du null
    
    // TODO: Ajouter les classes CSS
    // Pas de classe nécessaire par défaut
    
    // TODO: Définir le contenu HTML du li
    // Structure recommandée :
    // <span class="item-text">TEXTE</span>
    // <button class="delete-btn">×</button>
    li.innerHTML = ''; // Complétez ici
    
    // TODO: Ajouter un event listener sur le li entier
    // Au clic, appeler toggleCompleted()
    
    
    // TODO: Sélectionner le bouton supprimer dans le li
    // et ajouter un event listener qui appelle deleteItem()
    
    
    // TODO: Ajouter le li à la liste
    
    
    // TODO: Vider l'input
    
    
    // TODO: Mettre à jour le compteur
    updateCounter();
}


// ==========================================
// TODO 3 : FONCTION POUR SUPPRIMER UN ARTICLE
// ==========================================
/**
 * Cette fonction doit :
 * 1. Supprimer l'élément li
 * 2. Mettre à jour le compteur
 * 
 * @param {Event} event - L'événement de clic
 */

function deleteItem(event) {
    // TODO: Empêcher la propagation de l'événement
    // (pour éviter que le clic ne déclenche aussi toggleCompleted)
    
    
    // TODO: Récupérer l'élément li parent du bouton cliqué
    // Indice : event.target.parentElement
    const li = null; // Complétez ici
    
    // TODO: Supprimer le li
    // Utilisez .remove()
    
    
    // TODO: Mettre à jour le compteur
    updateCounter();
}


// ==========================================
// TODO 4 : FONCTION POUR BARRER/DÉBARRER
// ==========================================
/**
 * Cette fonction doit :
 * 1. Ajouter ou retirer la classe 'completed' sur le li
 * 
 * @param {Event} event - L'événement de clic
 */

function toggleCompleted(event) {
    // TODO: Récupérer l'élément li cliqué
    const li = null; // event.currentTarget ou event.target selon contexte
    
    // TODO: Toggle (ajouter/retirer) la classe 'completed'
    // Utilisez classList.toggle()
    
}


// ==========================================
// TODO 5 : FONCTION POUR METTRE À JOUR LE COMPTEUR
// ==========================================
/**
 * Cette fonction doit :
 * 1. Compter le nombre de <li> dans la liste
 * 2. Mettre à jour le textContent du compteur
 */

function updateCounter() {
    // TODO: Compter le nombre d'éléments li
    // Indice : querySelectorAll retourne une NodeList avec .length
    const count = 0; // Complétez ici
    
    // TODO: Mettre à jour le textContent du compteur
    
}


// ==========================================
// TODO 6 : AJOUTER LES EVENT LISTENERS
// ==========================================
/**
 * Ajoutez les event listeners nécessaires :
 * 1. Clic sur le bouton "Ajouter"
 * 2. Touche "Enter" dans l'input
 */

// TODO: Event listener sur le bouton addBtn
// Au clic, appeler addItem()


// TODO: Event listener sur l'input itemInput
// À l'événement 'keypress', vérifier si la touche est 'Enter'
// Si oui, appeler addItem()
// Exemple : if (event.key === 'Enter') { ... }


// ==========================================
// INITIALISATION
// ==========================================
// Mettre à jour le compteur au chargement de la page
updateCounter();


// ==========================================
// 🎉 FÉLICITATIONS !
// ==========================================
/**
 * Une fois l'exercice terminé, vous devriez pouvoir :
 * ✅ Ajouter des articles à votre liste
 * ✅ Supprimer des articles
 * ✅ Barrer/débarrer des articles
 * ✅ Voir le compteur se mettre à jour
 * 
 * PROCHAINES ÉTAPES :
 * 1. Tester votre application
 * 2. Commit Git : git add . && git commit -m "Exercice 1 terminé"
 * 3. Passer à l'Exercice 2 !
 * 
 * BONUS (si vous avez fini en avance) :
 * - Ajouter une confirmation avant suppression
 * - Ajouter un bouton "Tout supprimer"
 * - Sauvegarder la liste dans localStorage
 * - Ajouter des catégories (fruits, légumes, etc.)
 */ 