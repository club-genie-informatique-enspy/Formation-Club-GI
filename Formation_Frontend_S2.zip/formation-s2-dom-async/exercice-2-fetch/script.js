/**
 * EXERCICE 2 - GALERIE PHOTOS
 * 
 * Objectif : Récupérer et afficher des photos depuis une API
 * 
 * Fonctionnalités à implémenter :
 * 1. Récupérer 9 photos depuis Lorem Picsum
 * 2. Créer une carte pour chaque photo
 * 3. Afficher les photos dans une grille
 * 4. Gérer les états de chargement et d'erreur
 */

// ==========================================
// SÉLECTION DES ÉLÉMENTS DU DOM (DÉJÀ FAIT)
// ==========================================

const loadBtn = document.querySelector('#loadBtn');
const gallery = document.querySelector('#gallery');
const loadingSpinner = document.querySelector('#loadingSpinner');
const errorMessage = document.querySelector('#errorMessage');

// URL de l'API Lorem Picsum
const API_URL = 'https://picsum.photos/v2/list?page=1&limit=9';


// ==========================================
// FONCTIONS UTILITAIRES (DÉJÀ COMPLÉTÉES)
// ==========================================

/**
 * Affiche ou cache le spinner de chargement
 * @param {boolean} isLoading - true pour afficher, false pour cacher
 */
function toggleLoading(isLoading) {
    if (isLoading) {
        loadingSpinner.classList.remove('hidden');
        loadBtn.disabled = true;
    } else {
        loadingSpinner.classList.add('hidden');
        loadBtn.disabled = false;
    }
}

/**
 * Affiche ou cache le message d'erreur
 * @param {boolean} hasError - true pour afficher, false pour cacher
 */
function toggleError(hasError) {
    if (hasError) {
        errorMessage.classList.remove('hidden');
    } else {
        errorMessage.classList.add('hidden');
    }
}


// ==========================================
// TODO 1 : FONCTION POUR CRÉER UNE CARTE PHOTO
// ==========================================
/**
 * Crée un élément div.photo-card pour une photo
 * @param {Object} photo - Objet photo de l'API
 * @returns {HTMLElement} - L'élément div créé
 */

function createPhotoCard(photo) {
    // TODO: Créer un élément div
    const card = null; // Utilisez document.createElement('div')
    
    // TODO: Ajouter la classe 'photo-card'
    
    
    // TODO: Construire l'URL de l'image
    // IMPORTANT : Lorem Picsum utilise cette structure
    // { id, author, width, height, url, download_url }
    // Pour obtenir une image de taille fixe, utilisez :
    // https://picsum.photos/id/{ID}/400/300
    
    const imageUrl = null; // TODO: Construire l'URL avec photo.id
    
    // TODO: Définir le innerHTML de la carte
    // Structure recommandée :
    // <img src="..." alt="...">
    // <div class="photo-info">
    //   <div class="photo-title">Photo par {photo.author}</div>
    //   <div class="photo-id">Photo #{photo.id}</div>
    // </div>
    
    card.innerHTML = `
        
    `;
    
    // TODO: Retourner la carte
    return card;
}


// ==========================================
// TODO 2 : FONCTION PRINCIPALE - CHARGER LES PHOTOS
// ==========================================
/**
 * Récupère les photos depuis l'API et les affiche
 * Cette fonction doit être asynchrone !
 */

async function loadPhotos() {
    // Vider la galerie avant de charger
    gallery.innerHTML = '';
    
    // Cacher le message d'erreur
    toggleError(false);
    
    // Afficher le loading
    toggleLoading(true);
    
    try {
        // TODO: Faire la requête fetch vers API_URL
        // N'oubliez pas le await !
        const response = null; // TODO: Complétez ici avec fetch(API_URL)
        
        // TODO: Vérifier si la réponse est OK
        // Si response.ok === false, lancer une erreur
        if (!response.ok) {
            throw new Error('Erreur HTTP : ' + response.status);
        }
        
        // TODO: Convertir la réponse en JSON
        // N'oubliez pas le await !
        const photos = null; // TODO: Complétez ici avec response.json()
        
        // TODO: Pour chaque photo, créer une carte et l'ajouter à la galerie
        // Utilisez une boucle (for, forEach, etc.)
        // Pour chaque photo :
        //   1. Appeler createPhotoCard(photo)
        //   2. Ajouter la carte à gallery avec appendChild()
        
        
        
    } catch (error) {
        // En cas d'erreur, afficher le message d'erreur
        console.error('Erreur lors du chargement:', error);
        toggleError(true);
        
    } finally {
        // Dans tous les cas, cacher le loading
        toggleLoading(false);
    }
}


// ==========================================
// EVENT LISTENER (DÉJÀ FAIT)
// ==========================================

loadBtn.addEventListener('click', loadPhotos);


// ==========================================
// 🎉 FÉLICITATIONS !
// ==========================================
/**
 * Une fois l'exercice terminé, vous devriez pouvoir :
 * ✅ Cliquer sur "Charger les Photos"
 * ✅ Voir un spinner pendant le chargement
 * ✅ Voir 9 photos s'afficher dans une grille
 * ✅ Voir un message d'erreur si l'API ne répond pas
 * 
 * PROCHAINES ÉTAPES :
 * 1. Tester votre application avec Live Server
 * 2. Commit Git : git add . && git commit -m "Exercice 2 terminé"
 * 3. Passer au Mini-Projet !
 * 
 * BONUS (si vous avez fini en avance) :
 * - Charger automatiquement les photos au démarrage
 * - Ajouter un bouton "Charger plus" avec pagination
 * - Ajouter un modal pour voir l'image en grand
 */